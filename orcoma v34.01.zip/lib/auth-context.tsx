"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback, useMemo } from "react"

interface User {
  id: string
  username: string
  email: string
  role: "admin" | "user" | "viewer"
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
  isInitializing: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Usuarios de prueba
const TEST_USERS = [
  {
    id: "1",
    email: "admin@test.com",
    password: "admin123",
    username: "Administrador",
    role: "admin" as const,
  },
  {
    id: "2",
    email: "admin",
    password: "admin1234",
    username: "Admin ORCOMA",
    role: "admin" as const,
  },
  {
    id: "3",
    email: "user@test.com",
    password: "user123",
    username: "Usuario Test",
    role: "user" as const,
  },
]

function useAuthProvider(): AuthContextType {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isInitializing, setIsInitializing] = useState(true)

  // Efecto para cargar el usuario desde localStorage
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Pequeño delay para mostrar la animación de carga
        await new Promise((resolve) => setTimeout(resolve, 800))

        const savedUser = localStorage.getItem("orcoma_user")
        const authToken = localStorage.getItem("orcoma_auth_token")

        if (savedUser && authToken) {
          const userData = JSON.parse(savedUser)
          setUser(userData)
        }
      } catch (error) {
        console.error("Error al inicializar la autenticación:", error)
        // Limpiar datos corruptos
        localStorage.removeItem("orcoma_user")
        localStorage.removeItem("orcoma_auth_token")
      } finally {
        setIsInitializing(false)
      }
    }

    initializeAuth()
  }, [])

  // Función de login mejorada
  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)
    try {
      // Simular llamada a API con tiempo realista
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Buscar usuario en la lista de prueba
      const foundUser = TEST_USERS.find((u) => (u.email === email || u.username === email) && u.password === password)

      if (foundUser) {
        const userData: User = {
          id: foundUser.id,
          username: foundUser.username,
          email: foundUser.email,
          role: foundUser.role,
        }

        // Generar token simple para la demo
        const authToken = btoa(`${foundUser.id}:${Date.now()}`)

        setUser(userData)
        localStorage.setItem("orcoma_user", JSON.stringify(userData))
        localStorage.setItem("orcoma_auth_token", authToken)

        // También establecer cookie para el middleware
        document.cookie = `orcoma_auth=${authToken}; path=/; max-age=86400`

        return true
      }

      return false
    } catch (error) {
      console.error("Error en login:", error)
      return false
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Función logout mejorada
  const logout = useCallback(() => {
    setUser(null)
    localStorage.removeItem("orcoma_user")
    localStorage.removeItem("orcoma_auth_token")

    // Limpiar cookie
    document.cookie = "orcoma_auth=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT"
  }, [])

  // Memoizar el valor del contexto
  const contextValue = useMemo(
    () => ({
      user,
      login,
      logout,
      isLoading,
      isInitializing,
    }),
    [user, login, logout, isLoading, isInitializing],
  )

  return contextValue
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const auth = useAuthProvider()
  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
