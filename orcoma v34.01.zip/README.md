# ORCOMA S.A.S - Sistema de Gestión de Videos y Estadísticas

Este proyecto es una aplicación web desarrollada con Next.js para la gestión de videos de capacitación y generación de reportes estadísticos para ORCOMA S.A.S.

## 🚀 Características Principales

- **Gestión de Videos**: Subida, edición y eliminación de videos de capacitación
- **Estadísticas y Reportes**: Visualización de datos y generación de PDFs
- **Interfaz Optimizada**: Diseño responsivo y optimizado para rendimiento
- **Autenticación**: Sistema de login y registro con animaciones

## 📋 Requisitos del Sistema

- Node.js 18.0 o superior
- npm o yarn
- Base de datos (PostgreSQL, MySQL, o similar)

## 🛠️ Instalación

1. **Clonar el repositorio**:
   \`\`\`bash
   git clone [URL_DEL_REPOSITORIO]
   cd orcoma-sistema
   \`\`\`

2. **Instalar dependencias**:
   \`\`\`bash
   npm install
   \`\`\`

3. **Configurar variables de entorno**:
   \`\`\`bash
   cp .env.example .env.local
   \`\`\`

4. **Ejecutar en modo desarrollo**:
   \`\`\`bash
   npm run dev
   \`\`\`

## 🗄️ Estructura de Datos

### Interfaz Usuario (para estadísticas)

\`\`\`typescript
interface Usuario {
  id: number           // ID único del usuario
  nombre: string       // Nombre completo del usuario
  cargo: string        // Cargo/posición del usuario
  tema: string         // Tema de la evaluación
  fecha: string        // Fecha en formato YYYY-MM-DD
  realizado: boolean   // Estado de completitud (true/false)
}
\`\`\`

### Interfaz Video

\`\`\`typescript
interface Video {
  id: number           // ID único del video
  titulo: string       // Título del video
  descripcion: string  // Descripción del contenido
  duracion: string     // Duración en formato HH:MM:SS
  fecha: string        // Fecha de subida YYYY-MM-DD
}
\`\`\`

### Filtros para PDF

\`\`\`typescript
interface FiltrosPDF {
  cargo?: string           // Filtro por cargo (opcional)
  nombreBusqueda?: string  // Búsqueda por nombre (opcional)
  fecha?: string          // Filtro por fecha YYYY-MM-DD (opcional)
}
\`\`\`

## 🔧 Integración con Backend

### 1. Endpoint de Usuarios

**Ruta**: `GET /api/usuarios`

**Respuesta esperada**:
\`\`\`json
{
  "usuarios": [
    {
      "id": 1,
      "nombre": "Carlos Martínez",
      "cargo": "operario",
      "tema": "induccion",
      "fecha": "2024-02-08",
      "realizado": true
    }
  ],
  "total": 100,
  "pagina": 1,
  "porPagina": 10
}
\`\`\`

### 2. Endpoint de Videos

**Ruta**: `GET /api/videos`

**Respuesta esperada**:
\`\`\`json
{
  "videos": [
    {
      "id": 1,
      "titulo": "Introducción a la Seguridad",
      "descripcion": "Video introductorio sobre seguridad laboral",
      "duracion": "10:30",
      "fecha": "2024-02-15"
    }
  ]
}
\`\`\`

### 3. Subida de Videos

**Ruta**: `POST /api/videos`

**Formato de envío**:
\`\`\`javascript
const formData = new FormData();
formData.append('titulo', 'Título del video');
formData.append('descripcion', 'Descripción del video');
formData.append('video', archivoVideo); // File object
\`\`\`

## 📊 Generación de PDF

### Endpoint Implementado

**Ruta**: `POST /api/generar-pdf`

**Cuerpo de la solicitud**:
\`\`\`json
{
  "filtros": {
    "cargo": "operario",
    "nombreBusqueda": "Carlos",
    "fecha": "2024-02-08"
  }
}
\`\`\`

**Respuesta**: Archivo PDF binario con headers:
- `Content-Type: application/pdf`
- `Content-Disposition: attachment; filename="evaluaciones_orcoma.pdf"`

### Personalización del PDF

El PDF generado incluye:
- **Encabezado**: Logo y título de ORCOMA
- **Subtítulo**: Descripción del reporte
- **Tabla**: Datos filtrados con formato profesional
- **Indicadores visuales**: Círculos verdes para evaluaciones completadas

Para personalizar el diseño, modifica la función en `app/api/generar-pdf/route.ts`:

\`\`\`typescript
// Cambiar colores del encabezado
doc.setTextColor(242, 102, 22) // RGB para naranja

// Personalizar estilos de tabla
const tableOptions: UserOptions = {
  headStyles: {
    fillColor: [255, 255, 255], // Color de fondo del encabezado
    textColor: [0, 0, 0],       // Color del texto
    fontStyle: "bold"           // Estilo de fuente
  },
  bodyStyles: {
    lineWidth: 0.1,             // Grosor de líneas
    lineColor: [0, 0, 0]        // Color de líneas
  }
}
\`\`\`

## 🔍 Puntos de Integración Backend

### En `app/(dashboard)/stats/page.tsx`:

\`\`\`typescript
// LÍNEA 45-60: Cargar datos de usuarios
useEffect(() => {
  const fetchData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/usuarios');
      const data = await response.json();
      setUsuarios(data.usuarios);
    } catch (error) {
      console.error('Error al cargar usuarios:', error);
    } finally {
      setIsLoading(false);
    }
  };
  fetchData();
}, []);
\`\`\`

### En `app/(dashboard)/videos/page.tsx`:

\`\`\`typescript
// LÍNEA 35-50: Cargar videos
useEffect(() => {
  const fetchVideos = async () => {
    try {
      const response = await fetch('/api/videos');
      const data = await response.json();
      setVideos(data.videos);
    } catch (error) {
      console.error('Error al cargar videos:', error);
    }
  };
  fetchVideos();
}, []);

// LÍNEA 85-110: Subir nuevo video
const handleAddVideo = async (e: React.FormEvent) => {
  const formData = new FormData();
  formData.append('titulo', nuevoVideo.titulo);
  formData.append('descripcion', nuevoVideo.descripcion);
  formData.append('video', selectedFile);
  
  const response = await fetch('/api/videos', {
    method: 'POST',
    body: formData
  });
  
  if (response.ok) {
    const data = await response.json();
    // Actualizar lista de videos
  }
};
\`\`\`

## 🎨 Personalización de Estilos

### Colores Principales
- **Naranja ORCOMA**: `#f66616` (rgb(246, 102, 22))
- **Naranja Hover**: `#e55a0f`
- **Gris Texto**: `#374151`
- **Gris Claro**: `#f9fafb`

### Modificar Colores
Para cambiar los colores principales, actualiza las clases de Tailwind:
- `bg-orange-500` → `bg-[#f66616]`
- `text-orange-500` → `text-[#f66616]`
- `hover:bg-orange-600` → `hover:bg-[#e55a0f]`

## 📱 Optimizaciones Implementadas

### Frontend
1. **Lazy Loading**: Componentes pesados se cargan bajo demanda
2. **Memoización**: `useMemo` y `useCallback` para evitar re-renderizados
3. **Paginación**: Manejo eficiente de grandes conjuntos de datos
4. **Estados de carga**: Feedback visual durante operaciones

### Backend
1. **Generación de PDF en servidor**: Reduce carga del cliente
2. **Filtros en base de datos**: Procesamiento eficiente de consultas
3. **Compresión de respuestas**: Menor transferencia de datos

## 🔒 Consideraciones de Seguridad

### Autenticación
- Implementar JWT o sesiones para proteger rutas
- Validar permisos antes de generar PDFs
- Sanitizar inputs de usuario

### Subida de Archivos
- Validar tipos de archivo permitidos
- Limitar tamaño máximo de archivos
- Escanear archivos por malware

### API Endpoints
\`\`\`typescript
// Ejemplo de middleware de autenticación
export async function middleware(request: NextRequest) {
  const token = request.headers.get('authorization');
  
  if (!token) {
    return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  }
  
  // Validar token...
}
\`\`\`

## 🧪 Testing

### Probar Generación de PDF
\`\`\`javascript
// Test del endpoint
fetch('/api/generar-pdf', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ 
    filtros: { 
      cargo: 'operario',
      nombreBusqueda: 'Carlos',
      fecha: '2024-02-08'
    } 
  })
})
.then(response => response.blob())
.then(blob => {
  // Verificar que el blob es un PDF válido
  console.log('PDF generado:', blob.size, 'bytes');
});
\`\`\`

## 📈 Métricas y Monitoreo

### Logs Importantes
- Tiempo de generación de PDF
- Errores de subida de archivos
- Consultas lentas a la base de datos
- Uso de memoria durante operaciones

### Ejemplo de Logging
\`\`\`typescript
console.log(`PDF generado para ${usuarios.length} usuarios en ${Date.now() - startTime}ms`);
\`\`\`

## 🚀 Despliegue

### Variables de Entorno Requeridas
\`\`\`bash
DATABASE_URL=postgresql://user:password@localhost:5432/orcoma
NEXTAUTH_SECRET=your-secret-key
NEXTAUTH_URL=https://your-domain.com
\`\`\`

### Comandos de Despliegue
\`\`\`bash
npm run build
npm start
\`\`\`

## 📞 Soporte

Para preguntas técnicas sobre la implementación:
- Revisar los comentarios `// BACKEND:` en el código
- Consultar la documentación de Next.js
- Contactar al equipo de desarrollo

## 🔄 Actualizaciones Futuras

### Funcionalidades Planificadas
1. **Notificaciones en tiempo real**
2. **Dashboard avanzado con gráficos**
3. **Exportación a múltiples formatos**
4. **Sistema de roles y permisos**
5. **API REST completa**

### Mejoras de Rendimiento
1. **Cache de consultas frecuentes**
2. **Optimización de imágenes**
3. **CDN para archivos estáticos**
4. **Compresión de videos**

---

**Versión**: 1.0.0  
**Última actualización**: Enero 2025  
**Desarrollado para**: ORCOMA S.A.S
