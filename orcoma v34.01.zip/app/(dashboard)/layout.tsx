import Navbar from "@/components/navbar"
import { ProtectedRoute } from "@/components/protected-route"
import type React from "react"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ProtectedRoute>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </div>
    </ProtectedRoute>
  )
}
