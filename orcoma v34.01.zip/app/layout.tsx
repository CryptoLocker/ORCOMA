import "./globals.css"
import { Inter } from "next/font/google"
import { AuthProvider } from "@/lib/auth-context"
import { Toaster } from "react-hot-toast"
import { toastConfig } from "@/lib/toast"
import type React from "react"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  preload: true,
})

export const metadata = {
  title: "ORCOMA S.A.S - Sistema de Gestión",
  description: "Portal de acceso para Ingenieros Civiles - ORCOMA S.A.S",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body className={`${inter.className} bg-white`}>
        <AuthProvider>
          {children}
          <Toaster {...toastConfig} />
        </AuthProvider>
      </body>
    </html>
  )
}
