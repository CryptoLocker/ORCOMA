import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Solo rutas esenciales que requieren autenticación
  const protectedPaths = ["/admin", "/videos", "/stats"]
  const isProtectedPath = protectedPaths.some((path) => request.nextUrl.pathname.startsWith(path))

  if (isProtectedPath) {
    const token = request.cookies.get("orcoma_auth")

    if (!token) {
      console.log("No token found, redirecting to login")
      return NextResponse.redirect(new URL("/login", request.url))
    }
  }

  // Si está en login y ya está autenticado, redirigir al admin dashboard
  if (request.nextUrl.pathname === "/login") {
    const token = request.cookies.get("orcoma_auth")
    if (token) {
      console.log("User already authenticated, redirecting to admin")
      return NextResponse.redirect(new URL("/admin", request.url))
    }
  }

  // Redirigir root al admin si está autenticado
  if (request.nextUrl.pathname === "/") {
    const token = request.cookies.get("orcoma_auth")
    if (token) {
      return NextResponse.redirect(new URL("/admin", request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/", "/admin/:path*", "/videos/:path*", "/stats/:path*", "/login"],
}
