export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
  created_at: string;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  url: string;
  thumbnail_url: string;
  category: string;
  created_at: string;
}

export interface Question {
  id: string;
  video_id: string;
  type: 'multiple_choice' | 'open_ended' | 'rating';
  content: string;
  options?: string[];
}

export interface Response {
  id: string;
  question_id: string;
  user_id: string;
  content: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  message: string;
  status: 'read' | 'unread';
  created_at: string;
}