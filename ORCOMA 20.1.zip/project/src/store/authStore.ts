import { create } from 'zustand';
import { User } from '../types';
import { supabase } from '../lib/supabase';

interface AuthState {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  setUser: (user: User | null) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,
  signIn: async (email: string, password: string) => {
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (signInError) throw signInError;

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', (await supabase.auth.getUser()).data.user?.id)
      .single();

    if (profileError) throw profileError;

    const user = (await supabase.auth.getUser()).data.user;
    if (!user) throw new Error('No user found after sign in');

    set({
      user: {
        id: user.id,
        email: user.email!,
        role: profile.role,
        created_at: user.created_at,
      },
    });
  },
  signUp: async (email: string, password: string) => {
    const { error: signUpError, data } = await supabase.auth.signUp({
      email,
      password,
    });
    if (signUpError) throw signUpError;

    if (!data.user) throw new Error('No user returned from sign up');

    const { error: profileError } = await supabase.from('profiles').insert([
      {
        id: data.user.id,
        email: data.user.email,
        role: 'user',
      },
    ]);

    if (profileError) throw profileError;

    set({
      user: {
        id: data.user.id,
        email: data.user.email!,
        role: 'user',
        created_at: data.user.created_at,
      },
    });
  },
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null });
  },
  setUser: (user) => set({ user, loading: false }),
}));