import React from 'react';
import { Link } from 'react-router-dom';
import { Bell, Menu, Video, Home, Settings } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export const Navbar = () => {
  const { user, signOut } = useAuthStore();
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <Video className="h-8 w-8 text-orange-500" />
              <span className="ml-2 text-xl font-bold text-gray-800">O.R.C.O.M.A</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden sm:flex sm:items-center sm:space-x-8">
            <Link to="/" className="text-gray-700 hover:text-orange-500">
              <Home className="h-5 w-5" />
            </Link>
            <Link to="/videos" className="text-gray-700 hover:text-orange-500">
              My Videos
            </Link>
            {user && (
              <>
                <Link to="/notifications" className="relative text-gray-700 hover:text-orange-500">
                  <Bell className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 h-4 w-4 bg-orange-500 rounded-full text-xs text-white flex items-center justify-center">
                    3
                  </span>
                </Link>
                {user.role === 'admin' && (
                  <Link to="/admin" className="text-gray-700 hover:text-orange-500">
                    <Settings className="h-5 w-5" />
                  </Link>
                )}
                <button
                  onClick={() => signOut()}
                  className="text-gray-700 hover:text-orange-500"
                >
                  Sign Out
                </button>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="sm:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-700 hover:text-orange-500"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className="block px-3 py-2 text-gray-700 hover:text-orange-500"
            >
              Home
            </Link>
            <Link
              to="/videos"
              className="block px-3 py-2 text-gray-700 hover:text-orange-500"
            >
              My Videos
            </Link>
            {user && (
              <>
                <Link
                  to="/notifications"
                  className="block px-3 py-2 text-gray-700 hover:text-orange-500"
                >
                  Notifications
                </Link>
                {user.role === 'admin' && (
                  <Link
                    to="/admin"
                    className="block px-3 py-2 text-gray-700 hover:text-orange-500"
                  >
                    Admin Panel
                  </Link>
                )}
                <button
                  onClick={() => signOut()}
                  className="block w-full text-left px-3 py-2 text-gray-700 hover:text-orange-500"
                >
                  Sign Out
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};