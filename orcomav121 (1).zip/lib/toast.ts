import toast from "react-hot-toast"

// Configuración personalizada para ORCOMA
export const showToast = {
  success: (message: string, description?: string) => {
    toast.success(description ? `${message}\n${description}` : message, {
      duration: 2000,
      position: "top-right",
      style: {
        background: "#10B981",
        color: "#fff",
        borderRadius: "8px",
        padding: "12px 16px",
        fontSize: "14px",
        fontWeight: "500",
        boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      },
      iconTheme: {
        primary: "#fff",
        secondary: "#10B981",
      },
    })
  },

  error: (message: string, description?: string) => {
    toast.error(description ? `${message}\n${description}` : message, {
      duration: 3000,
      position: "top-right",
      style: {
        background: "#EF4444",
        color: "#fff",
        borderRadius: "8px",
        padding: "12px 16px",
        fontSize: "14px",
        fontWeight: "500",
        boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      },
      iconTheme: {
        primary: "#fff",
        secondary: "#EF4444",
      },
    })
  },

  loading: (message: string) => {
    return toast.loading(message, {
      position: "top-right",
      style: {
        background: "#F59E0B",
        color: "#fff",
        borderRadius: "8px",
        padding: "12px 16px",
        fontSize: "14px",
        fontWeight: "500",
        boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      },
    })
  },

  info: (message: string, description?: string) => {
    toast(description ? `${message}\n${description}` : message, {
      duration: 2000,
      position: "top-right",
      icon: "ℹ️",
      style: {
        background: "#3B82F6",
        color: "#fff",
        borderRadius: "8px",
        padding: "12px 16px",
        fontSize: "14px",
        fontWeight: "500",
        boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      },
    })
  },

  dismiss: (toastId?: string) => {
    toast.dismiss(toastId)
  },
}

// Configuración global de toast
export const toastConfig = {
  duration: 2000,
  position: "top-right" as const,
  reverseOrder: false,
  gutter: 8,
  containerClassName: "",
  containerStyle: {},
  toastOptions: {
    className: "",
    duration: 2000,
    style: {
      background: "#fff",
      color: "#363636",
      borderRadius: "8px",
      padding: "12px 16px",
      fontSize: "14px",
      fontWeight: "500",
      boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
    },
  },
}
