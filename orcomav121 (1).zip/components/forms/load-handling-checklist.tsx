"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { submitLoadHandlingChecklist } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

interface LoadHandlingChecklistData {
  inspector: string
  fecha: string
  area: string
  item1: string
  item2: string
  item3: string
  item4: string
  item5: string
  item6: string
  item7: string
  observaciones: string
}

export default function LoadHandlingChecklist() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<LoadHandlingChecklistData>({
    inspector: "",
    fecha: "",
    area: "",
    item1: "",
    item2: "",
    item3: "",
    item4: "",
    item5: "",
    item6: "",
    item7: "",
    observaciones: "",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await submitLoadHandlingChecklist(formData)
      toast({
        title: "Lista de verificación guardada",
        description: "La verificación de manipulación de cargas ha sido registrada exitosamente.",
      })
      // Reset form
      setFormData({
        inspector: "",
        fecha: "",
        area: "",
        item1: "",
        item2: "",
        item3: "",
        item4: "",
        item5: "",
        item6: "",
        item7: "",
        observaciones: "",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un problema al guardar la verificación. Inténtalo de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const checklistItems = [
    "¿Se ha evaluado el peso y la frecuencia de levantamiento de la carga?",
    "¿Se mantiene la carga en la zona segura (entre rodillas y codos)?",
    "¿Se mantiene la carga lo más pegada al cuerpo posible?",
    "¿Se evita girar o inclinar el torso al levantar o transportar la carga?",
    "¿La carga tiene un agarre firme, cómodo y seguro?",
    "¿La superficie de trabajo está en buenas condiciones (limpia, seca, sin obstáculos)?",
    "¿Se utilizan las ayudas mecánicas disponibles (carretillas, gatos) para cargas pesadas?",
  ]

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="border-orange-200">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 border-b border-orange-200">
          <CardTitle className="text-orange-800 text-center">
            LISTA DE VERIFICACIÓN: MANIPULACIÓN SEGURA DE CARGAS
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            {/* Información General */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="inspector">Realizado por</Label>
                <Input
                  id="inspector"
                  value={formData.inspector}
                  onChange={(e) => setFormData((prev) => ({ ...prev, inspector: e.target.value }))}
                  required
                />
              </div>
              <div>
                <Label htmlFor="fecha">Fecha de Inspección</Label>
                <Input
                  id="fecha"
                  type="date"
                  value={formData.fecha}
                  onChange={(e) => setFormData((prev) => ({ ...prev, fecha: e.target.value }))}
                  required
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="area">Área / Proyecto</Label>
                <Input
                  id="area"
                  value={formData.area}
                  onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))}
                  required
                />
              </div>
            </div>

            {/* Puntos de Verificación */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">Puntos a Verificar</h3>
              <div className="space-y-6">
                {checklistItems.map((item, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <Label className="font-medium text-gray-700 mb-3 block">
                      {index + 1}. {item}
                    </Label>
                    <RadioGroup
                      value={formData[`item${index + 1}` as keyof LoadHandlingChecklistData] as string}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, [`item${index + 1}`]: value }))}
                    >
                      <div className="flex items-center space-x-6">
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="si" id={`item${index + 1}_si`} />
                          <Label htmlFor={`item${index + 1}_si`}>Sí</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="no" id={`item${index + 1}_no`} />
                          <Label htmlFor={`item${index + 1}_no`}>No</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="na" id={`item${index + 1}_na`} />
                          <Label htmlFor={`item${index + 1}_na`}>N/A</Label>
                        </div>
                      </div>
                    </RadioGroup>
                  </div>
                ))}
              </div>
            </div>

            {/* Observaciones */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">
                Observaciones y Acciones a Tomar
              </h3>
              <div>
                <Label htmlFor="observaciones">Describa cualquier hallazgo o recomendación</Label>
                <Textarea
                  id="observaciones"
                  rows={5}
                  value={formData.observaciones}
                  onChange={(e) => setFormData((prev) => ({ ...prev, observaciones: e.target.value }))}
                />
              </div>
              <div className="mt-8">
                <Label className="font-medium">Firma del Inspector:</Label>
                <div className="border-t mt-16 pt-2"></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg font-semibold"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Guardando...
            </>
          ) : (
            "Guardar Verificación"
          )}
        </Button>
      </div>
    </form>
  )
}
