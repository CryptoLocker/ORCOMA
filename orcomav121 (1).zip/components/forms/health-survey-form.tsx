"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { submitHealthSurvey } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

interface HealthSurveyData {
  autorizacion: boolean
  nombre: string
  cedula: string
  fecha: string
  edad: string
  sexo: string
  conviveMenor: string
  conviveMayor: string
  peso: string
  talla: string
  buenaSalud: string
  sintomas: string
  diabetico: string
  hipertenso: string
  otrasEnfermedades: string
  incidenteProyecto: string
  medicacion: string
  cualMedicacion: string
  aptoLabor: string
  argumentoApto: string
  desayuno: string
  fumador: string
  fumadorCantidad: string
}

export default function HealthSurveyForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<HealthSurveyData>({
    autorizacion: false,
    nombre: "",
    cedula: "",
    fecha: "",
    edad: "",
    sexo: "",
    conviveMenor: "",
    conviveMayor: "",
    peso: "",
    talla: "",
    buenaSalud: "",
    sintomas: "",
    diabetico: "",
    hipertenso: "",
    otrasEnfermedades: "",
    incidenteProyecto: "",
    medicacion: "",
    cualMedicacion: "",
    aptoLabor: "",
    argumentoApto: "",
    desayuno: "",
    fumador: "",
    fumadorCantidad: "",
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.autorizacion) {
      toast({
        title: "Autorización requerida",
        description: "Debe autorizar el manejo de la información para continuar.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      await submitHealthSurvey(formData)
      toast({
        title: "Encuesta enviada",
        description: "La encuesta de condiciones de salud ha sido registrada exitosamente.",
      })
      // Reset form
      setFormData({
        autorizacion: false,
        nombre: "",
        cedula: "",
        fecha: "",
        edad: "",
        sexo: "",
        conviveMenor: "",
        conviveMayor: "",
        peso: "",
        talla: "",
        buenaSalud: "",
        sintomas: "",
        diabetico: "",
        hipertenso: "",
        otrasEnfermedades: "",
        incidenteProyecto: "",
        medicacion: "",
        cualMedicacion: "",
        aptoLabor: "",
        argumentoApto: "",
        desayuno: "",
        fumador: "",
        fumadorCantidad: "",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un problema al enviar la encuesta. Inténtalo de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="border-orange-200">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 border-b border-orange-200">
          <CardTitle className="text-orange-800 text-center">ENCUESTA DE CONDICIONES DE SALUD INDIVIDUAL</CardTitle>
          <p className="text-sm text-gray-600 text-center">GCSST-REG-047</p>
        </CardHeader>
        <CardContent className="p-6">
          {/* Autorización */}
          <div className="bg-blue-50 border-l-4 border-blue-500 text-blue-700 p-4 mb-6 rounded-md">
            <p className="text-sm mb-4">
              Toda la información se recoge con fines estrictamente de interés de SST, para proteger y salvaguardar un
              interés esencial para la vida de las personas. En consecuencia, autorizo a la ARL y a la Empresa para el
              manejo de la información aportada en esta encuesta para desarrollar acciones de promoción y prevención.
            </p>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="autorizacion"
                checked={formData.autorizacion}
                onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, autorizacion: checked as boolean }))}
              />
              <Label htmlFor="autorizacion" className="font-medium">
                AUTORIZO
              </Label>
            </div>
          </div>

          <div className="space-y-6">
            {/* Información Personal */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">1. Información Personal</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nombre">Nombres y Apellidos</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nombre: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="cedula">Cédula</Label>
                  <Input
                    id="cedula"
                    value={formData.cedula}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cedula: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="fecha">Fecha</Label>
                  <Input
                    id="fecha"
                    type="date"
                    value={formData.fecha}
                    onChange={(e) => setFormData((prev) => ({ ...prev, fecha: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label>Edad</Label>
                  <RadioGroup
                    value={formData.edad}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, edad: value }))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="menor_59" id="edad_menor" />
                      <Label htmlFor="edad_menor">59 años o menor</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="mayor_60" id="edad_mayor" />
                      <Label htmlFor="edad_mayor">60 años o mayor</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div>
                  <Label>Sexo</Label>
                  <RadioGroup
                    value={formData.sexo}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, sexo: value }))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="masculino" id="sexo_m" />
                      <Label htmlFor="sexo_m">Masculino</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="femenino" id="sexo_f" />
                      <Label htmlFor="sexo_f">Femenino</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div>
                  <Label>Personas con quien convive</Label>
                  <div className="space-y-2 mt-2">
                    <div>
                      <Label className="font-normal">Menores de 5 años:</Label>
                      <RadioGroup
                        value={formData.conviveMenor}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, conviveMenor: value }))}
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="si" id="convive_menor_si" />
                            <Label htmlFor="convive_menor_si">Sí</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="no" id="convive_menor_no" />
                            <Label htmlFor="convive_menor_no">No</Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>
                    <div>
                      <Label className="font-normal">Mayores de 60 años:</Label>
                      <RadioGroup
                        value={formData.conviveMayor}
                        onValueChange={(value) => setFormData((prev) => ({ ...prev, conviveMayor: value }))}
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="si" id="convive_mayor_si" />
                            <Label htmlFor="convive_mayor_si">Sí</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="no" id="convive_mayor_no" />
                            <Label htmlFor="convive_mayor_no">No</Label>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="peso">Peso (Kg - dato aproximado)</Label>
                  <Input
                    id="peso"
                    type="number"
                    step="0.1"
                    value={formData.peso}
                    onChange={(e) => setFormData((prev) => ({ ...prev, peso: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="talla">Talla (m - dato aproximado)</Label>
                  <Input
                    id="talla"
                    type="number"
                    step="0.01"
                    value={formData.talla}
                    onChange={(e) => setFormData((prev) => ({ ...prev, talla: e.target.value }))}
                  />
                </div>
              </div>
            </div>

            {/* Antecedentes Médicos */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">
                2. Antecedentes Médicos Importantes
              </h3>
              <div className="space-y-6">
                <div>
                  <Label>1. ¿Se encuentra actualmente en buen estado de salud?</Label>
                  <RadioGroup
                    value={formData.buenaSalud}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, buenaSalud: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="salud_si" />
                        <Label htmlFor="salud_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="salud_no" />
                        <Label htmlFor="salud_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="sintomas">2. Si su respuesta anterior es NO, ¿Qué síntomas presenta?</Label>
                  <Textarea
                    id="sintomas"
                    rows={3}
                    value={formData.sintomas}
                    onChange={(e) => setFormData((prev) => ({ ...prev, sintomas: e.target.value }))}
                  />
                </div>

                <div>
                  <Label>3. ¿Usted ha sido diagnosticado como diabético?</Label>
                  <RadioGroup
                    value={formData.diabetico}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, diabetico: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="diabetico_si" />
                        <Label htmlFor="diabetico_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="diabetico_no" />
                        <Label htmlFor="diabetico_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label>4. ¿Usted ha sido diagnosticado Hipertenso?</Label>
                  <RadioGroup
                    value={formData.hipertenso}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, hipertenso: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="hipertenso_si" />
                        <Label htmlFor="hipertenso_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="hipertenso_no" />
                        <Label htmlFor="hipertenso_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label>
                    5. ¿Le han diagnosticado una o varias de estas enfermedades? (Insuficiencia cardíaca, Infarto de
                    miocardio, Cardiopatía congénita, etc.)
                  </Label>
                  <RadioGroup
                    value={formData.otrasEnfermedades}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, otrasEnfermedades: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="otras_enf_si" />
                        <Label htmlFor="otras_enf_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="otras_enf_no" />
                        <Label htmlFor="otras_enf_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label>6. ¿Ha sufrido algún incidente durante la realización de sus labores en este proyecto?</Label>
                  <RadioGroup
                    value={formData.incidenteProyecto}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, incidenteProyecto: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="incidente_si" />
                        <Label htmlFor="incidente_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="incidente_no" />
                        <Label htmlFor="incidente_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label>7. ¿Recibe algún tipo de medicación o tratamiento por alguna enfermedad?</Label>
                  <RadioGroup
                    value={formData.medicacion}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, medicacion: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="medicacion_si" />
                        <Label htmlFor="medicacion_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="medicacion_no" />
                        <Label htmlFor="medicacion_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="cualMedicacion">8. ¿Cuál?</Label>
                  <Input
                    id="cualMedicacion"
                    value={formData.cualMedicacion}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cualMedicacion: e.target.value }))}
                  />
                </div>

                <div>
                  <Label>9. ¿Considera usted que se encuentra apto para realizar las labores encomendadas?</Label>
                  <RadioGroup
                    value={formData.aptoLabor}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, aptoLabor: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="apto_si" />
                        <Label htmlFor="apto_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="apto_no" />
                        <Label htmlFor="apto_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                  <div className="mt-4">
                    <Label htmlFor="argumentoApto">Si su respuesta es NO, por favor argumente:</Label>
                    <Textarea
                      id="argumentoApto"
                      rows={3}
                      value={formData.argumentoApto}
                      onChange={(e) => setFormData((prev) => ({ ...prev, argumentoApto: e.target.value }))}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Hábitos */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">3. Hábitos</h3>
              <div className="space-y-6">
                <div>
                  <Label>1. ¿Desayuna antes de salir de casa?</Label>
                  <RadioGroup
                    value={formData.desayuno}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, desayuno: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="desayuno_si" />
                        <Label htmlFor="desayuno_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="desayuno_no" />
                        <Label htmlFor="desayuno_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label>2. ¿Usted es fumador?</Label>
                  <RadioGroup
                    value={formData.fumador}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, fumador: value }))}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="si" id="fumador_si" />
                        <Label htmlFor="fumador_si">Sí</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="no" id="fumador_no" />
                        <Label htmlFor="fumador_no">No</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="fumadorCantidad">Si es fumador, ¿Cuántos cigarrillos al día?</Label>
                  <Input
                    id="fumadorCantidad"
                    type="number"
                    value={formData.fumadorCantidad}
                    onChange={(e) => setFormData((prev) => ({ ...prev, fumadorCantidad: e.target.value }))}
                  />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg font-semibold"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Enviando...
            </>
          ) : (
            "Enviar Encuesta"
          )}
        </Button>
      </div>
    </form>
  )
}
