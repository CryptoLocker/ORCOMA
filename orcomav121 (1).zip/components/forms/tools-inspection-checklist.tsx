"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { submitToolsInspectionChecklist } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"

interface ToolsInspectionData {
  inspector: string
  fecha: string
  area: string
  martilloMango: string
  martilloMangoAccion: string
  martilloCabeza: string
  martilloCabezaAccion: string
  alicatesMandibula: string
  alicatesMandibulaAccion: string
  alicatesMango: string
  alicatesMangoAccion: string
  destPunta: string
  destPuntaAccion: string
  destMango: string
  destMangoAccion: string
  electCable: string
  electCableAccion: string
  electCarcasa: string
  electCarcasaAccion: string
  electGuarda: string
  electGuardaAccion: string
  observaciones: string
}

export default function ToolsInspectionChecklist() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<ToolsInspectionData>({
    inspector: "",
    fecha: "",
    area: "",
    martilloMango: "",
    martilloMangoAccion: "",
    martilloCabeza: "",
    martilloCabezaAccion: "",
    alicatesMandibula: "",
    alicatesMandibulaAccion: "",
    alicatesMango: "",
    alicatesMangoAccion: "",
    destPunta: "",
    destPuntaAccion: "",
    destMango: "",
    destMangoAccion: "",
    electCable: "",
    electCableAccion: "",
    electCarcasa: "",
    electCarcasaAccion: "",
    electGuarda: "",
    electGuardaAccion: "",
    observaciones: ""
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await submitToolsInspectionChecklist(formData)
      toast({
        title: "Inspección guardada",
        description: "La inspección de herramientas ha sido registrada exitosamente.",
      })
      // Reset form
      setFormData({
        inspector: "",
        fecha: "",
        area: "",
        martilloMango: "",
        martilloMangoAccion: "",
        martilloCabeza: "",
        martilloCabezaAccion: "",
        alicatesMandibula: "",
        alicatesMandibulaAccion: "",
        alicatesMango: "",
        alicatesMangoAccion: "",
        destPunta: "",
        destPuntaAccion: "",
        destMango: "",
        destMangoAccion: "",
        electCable: "",
        electCableAccion: "",
        electCarcasa: "",
        electCarcasaAccion: "",
        electGuarda: "",
        electGuardaAccion: "",
        observaciones: ""
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un problema al guardar la inspección. Inténtalo de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const InspectionRow = ({ 
    tool, 
    point, 
    stateField, 
    actionField 
  }: { 
    tool: string
    point: string
    stateField: keyof ToolsInspectionData
    actionField: keyof ToolsInspectionData
  }) => (
    <tr>
      <td className="border p-3 font-medium">{tool}</td>
      <td className="border p-3">{point}</td>
      <td className="border p-3">
        <RadioGroup 
          value={formData[stateField] as string} 
          onValueChange={(value) => setFormData(prev => ({...prev, [stateField]: value}))}
        >
          <div className="flex justify-center space-x-4">
            <div className="flex items-center space-x-1">
              <RadioGroupItem value="b" id={`${stateField}_b`} />
              <Label htmlFor={`${stateField}_b`}>B</Label>
            </div>
            <div className="flex items-center space-x-1">
              <RadioGroupItem value="m" id={`${stateField}_m`} />
              <Label htmlFor={`${stateField}_m`}>M</Label>
            </div>
            <div className="flex items-center space-x-1">
              <RadioGroupItem value="na" id={`${stateField}_na`} />
              <Label htmlFor={`${stateField}_na`}>NA</Label>
            </div>
          </div>
        </RadioGroup>
      </td>
      <td className="border p-3">
        <Input
          value={formData[actionField] as string}
          onChange={(e) => setFormData(prev => ({...prev, [actionField]: e.target.value}))}
          placeholder="Acción requerida"
        />
      </td>
    </tr>
  )

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="border-orange-200">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 border-b border-orange-\
