"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { submitAccidentInvestigation } from "@/lib/actions"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Plus, Trash2 } from "lucide-react"

interface AccidentInvestigationData {
  tipoEvento: string
  fechaEvento: string
  horaEvento: string
  lugarEvento: string
  fechaReporte: string
  nombreAfectado: string
  cedulaAfectado: string
  cargoAfectado: string
  proyectoAfectado: string
  descripcionEvento: string
  parteCuerpo: string
  tipoLesion: string
  causasInmediatas: string
  causasBasicas: string
  planAccion: Array<{
    accion: string
    responsable: string
    fechaEjecucion: string
    estado: string
  }>
  equipoInvestigador: Array<{
    nombre: string
    cargo: string
  }>
}

export default function AccidentInvestigationForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<AccidentInvestigationData>({
    tipoEvento: "",
    fechaEvento: "",
    horaEvento: "",
    lugarEvento: "",
    fechaReporte: "",
    nombreAfectado: "",
    cedulaAfectado: "",
    cargoAfectado: "",
    proyectoAfectado: "",
    descripcionEvento: "",
    parteCuerpo: "",
    tipoLesion: "",
    causasInmediatas: "",
    causasBasicas: "",
    planAccion: [{ accion: "", responsable: "", fechaEjecucion: "", estado: "Pendiente" }],
    equipoInvestigador: [
      { nombre: "", cargo: "Jefe Inmediato" },
      { nombre: "", cargo: "Miembro COPASST" },
      { nombre: "", cargo: "Responsable SST" },
    ],
  })
  const { toast } = useToast()

  const addPlanAccion = () => {
    setFormData((prev) => ({
      ...prev,
      planAccion: [...prev.planAccion, { accion: "", responsable: "", fechaEjecucion: "", estado: "Pendiente" }],
    }))
  }

  const removePlanAccion = (index: number) => {
    if (formData.planAccion.length > 1) {
      setFormData((prev) => ({
        ...prev,
        planAccion: prev.planAccion.filter((_, i) => i !== index),
      }))
    }
  }

  const addInvestigador = () => {
    setFormData((prev) => ({
      ...prev,
      equipoInvestigador: [...prev.equipoInvestigador, { nombre: "", cargo: "" }],
    }))
  }

  const removeInvestigador = (index: number) => {
    if (formData.equipoInvestigador.length > 3) {
      setFormData((prev) => ({
        ...prev,
        equipoInvestigador: prev.equipoInvestigador.filter((_, i) => i !== index),
      }))
    }
  }

  const updatePlanAccion = (index: number, field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      planAccion: prev.planAccion.map((item, i) => (i === index ? { ...item, [field]: value } : item)),
    }))
  }

  const updateInvestigador = (index: number, field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      equipoInvestigador: prev.equipoInvestigador.map((item, i) => (i === index ? { ...item, [field]: value } : item)),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      await submitAccidentInvestigation(formData)
      toast({
        title: "Investigación guardada",
        description: "La investigación de accidente ha sido registrada exitosamente.",
      })
      // Reset form
      setFormData({
        tipoEvento: "",
        fechaEvento: "",
        horaEvento: "",
        lugarEvento: "",
        fechaReporte: "",
        nombreAfectado: "",
        cedulaAfectado: "",
        cargoAfectado: "",
        proyectoAfectado: "",
        descripcionEvento: "",
        parteCuerpo: "",
        tipoLesion: "",
        causasInmediatas: "",
        causasBasicas: "",
        planAccion: [{ accion: "", responsable: "", fechaEjecucion: "", estado: "Pendiente" }],
        equipoInvestigador: [
          { nombre: "", cargo: "Jefe Inmediato" },
          { nombre: "", cargo: "Miembro COPASST" },
          { nombre: "", cargo: "Responsable SST" },
        ],
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un problema al guardar la investigación. Inténtalo de nuevo.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="border-orange-200">
        <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 border-b border-orange-200">
          <CardTitle className="text-orange-800 text-center">
            FORMATO DE INVESTIGACIÓN DE INCIDENTES, ACCIDENTES Y ENFERMEDADES LABORALES
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {/* Información General del Evento */}
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">
                1. Información General del Evento
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="tipoEvento">Tipo de Evento</Label>
                  <Select
                    value={formData.tipoEvento}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, tipoEvento: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="incidente">Incidente</SelectItem>
                      <SelectItem value="accidente_trabajo">Accidente de Trabajo</SelectItem>
                      <SelectItem value="enfermedad_laboral">Enfermedad Laboral</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fechaEvento">Fecha del Evento</Label>
                  <Input
                    id="fechaEvento"
                    type="date"
                    value={formData.fechaEvento}
                    onChange={(e) => setFormData((prev) => ({ ...prev, fechaEvento: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="horaEvento">Hora del Evento</Label>
                  <Input
                    id="horaEvento"
                    type="time"
                    value={formData.horaEvento}
                    onChange={(e) => setFormData((prev) => ({ ...prev, horaEvento: e.target.value }))}
                    required
                  />
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor="lugarEvento">Lugar Exacto del Evento</Label>
                  <Input
                    id="lugarEvento"
                    value={formData.lugarEvento}
                    onChange={(e) => setFormData((prev) => ({ ...prev, lugarEvento: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="fechaReporte">Fecha del Reporte</Label>
                  <Input
                    id="fechaReporte"
                    type="date"
                    value={formData.fechaReporte}
                    onChange={(e) => setFormData((prev) => ({ ...prev, fechaReporte: e.target.value }))}
                    required
                  />
                </div>
              </div>
            </div>

            {/* Información del Afectado */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">
                2. Información del Trabajador Afectado (Si aplica)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nombreAfectado">Nombre Completo</Label>
                  <Input
                    id="nombreAfectado"
                    value={formData.nombreAfectado}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nombreAfectado: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="cedulaAfectado">Cédula</Label>
                  <Input
                    id="cedulaAfectado"
                    value={formData.cedulaAfectado}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cedulaAfectado: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="cargoAfectado">Cargo</Label>
                  <Input
                    id="cargoAfectado"
                    value={formData.cargoAfectado}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cargoAfectado: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="proyectoAfectado">Proyecto / Área</Label>
                  <Input
                    id="proyectoAfectado"
                    value={formData.proyectoAfectado}
                    onChange={(e) => setFormData((prev) => ({ ...prev, proyectoAfectado: e.target.value }))}
                  />
                </div>
              </div>
            </div>

            {/* Descripción del Evento */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">3. Descripción del Evento</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="descripcionEvento">
                    Describa detalladamente lo sucedido (qué, cómo, cuándo, dónde, por qué)
                  </Label>
                  <Textarea
                    id="descripcionEvento"
                    rows={6}
                    value={formData.descripcionEvento}
                    onChange={(e) => setFormData((prev) => ({ ...prev, descripcionEvento: e.target.value }))}
                    required
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="parteCuerpo">Parte(s) del cuerpo afectada(s)</Label>
                    <Input
                      id="parteCuerpo"
                      value={formData.parteCuerpo}
                      onChange={(e) => setFormData((prev) => ({ ...prev, parteCuerpo: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="tipoLesion">Tipo de lesión (herida, fractura, contusión, etc.)</Label>
                    <Input
                      id="tipoLesion"
                      value={formData.tipoLesion}
                      onChange={(e) => setFormData((prev) => ({ ...prev, tipoLesion: e.target.value }))}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Análisis de Causas */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">4. Análisis de Causas</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="causasInmediatas">Causas Inmediatas (Actos y Condiciones Inseguras)</Label>
                  <Textarea
                    id="causasInmediatas"
                    rows={5}
                    placeholder="Ej: No usar EPP, piso resbaloso, falta de señalización..."
                    value={formData.causasInmediatas}
                    onChange={(e) => setFormData((prev) => ({ ...prev, causasInmediatas: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="causasBasicas">Causas Básicas (Factores Personales y de Trabajo)</Label>
                  <Textarea
                    id="causasBasicas"
                    rows={5}
                    placeholder="Ej: Falta de capacitación, mantenimiento deficiente, procedimientos inadecuados..."
                    value={formData.causasBasicas}
                    onChange={(e) => setFormData((prev) => ({ ...prev, causasBasicas: e.target.value }))}
                  />
                </div>
              </div>
            </div>

            {/* Plan de Acción */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">
                5. Plan de Acción (Medidas Correctivas y Preventivas)
              </h3>
              <div className="space-y-4">
                {formData.planAccion.map((accion, index) => (
                  <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 border rounded-lg">
                    <div>
                      <Label>Acción Correctiva / Preventiva</Label>
                      <Textarea
                        rows={2}
                        value={accion.accion}
                        onChange={(e) => updatePlanAccion(index, "accion", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Responsable</Label>
                      <Input
                        value={accion.responsable}
                        onChange={(e) => updatePlanAccion(index, "responsable", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Fecha de Ejecución</Label>
                      <Input
                        type="date"
                        value={accion.fechaEjecucion}
                        onChange={(e) => updatePlanAccion(index, "fechaEjecucion", e.target.value)}
                      />
                    </div>
                    <div className="flex flex-col">
                      <Label>Estado</Label>
                      <div className="flex gap-2 items-center">
                        <Select
                          value={accion.estado}
                          onValueChange={(value) => updatePlanAccion(index, "estado", value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Pendiente">Pendiente</SelectItem>
                            <SelectItem value="Completado">Completado</SelectItem>
                          </SelectContent>
                        </Select>
                        {formData.planAccion.length > 1 && (
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removePlanAccion(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={addPlanAccion}
                  className="text-orange-600 border-orange-300 hover:bg-orange-50 bg-transparent"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Añadir Acción
                </Button>
              </div>
            </div>

            {/* Equipo Investigador */}
            <div>
              <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">6. Equipo Investigador</h3>
              <div className="space-y-4">
                {formData.equipoInvestigador.map((investigador, index) => (
                  <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 border rounded-lg">
                    <div>
                      <Label>Nombre Completo</Label>
                      <Input
                        value={investigador.nombre}
                        onChange={(e) => updateInvestigador(index, "nombre", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Cargo</Label>
                      <Input
                        value={investigador.cargo}
                        onChange={(e) => updateInvestigador(index, "cargo", e.target.value)}
                      />
                    </div>
                    <div className="flex items-end">
                      {formData.equipoInvestigador.length > 3 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeInvestigador(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={addInvestigador}
                  className="text-orange-600 border-orange-300 hover:bg-orange-50 bg-transparent"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Añadir Miembro
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg font-semibold"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Guardando...
            </>
          ) : (
            "Finalizar y Guardar Investigación"
          )}
        </Button>
      </div>
    </form>
  )
}
