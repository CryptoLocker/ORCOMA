"use client"

interface LoadingDotsProps {
  size?: "sm" | "md" | "lg"
  color?: "orange" | "blue" | "gray"
}

export function LoadingDots({ size = "md", color = "orange" }: LoadingDotsProps) {
  const sizeClasses = {
    sm: "h-3 w-3",
    md: "h-5 w-5",
    lg: "h-6 w-6",
  }

  const colorClasses = {
    orange: {
      base: "bg-orange-200",
      active: "bg-orange-500",
      shadow: "rgba(251, 146, 60, 0.7)",
    },
    blue: {
      base: "bg-blue-200",
      active: "bg-blue-500",
      shadow: "rgba(59, 130, 246, 0.7)",
    },
    gray: {
      base: "bg-gray-200",
      active: "bg-gray-500",
      shadow: "rgba(107, 114, 128, 0.7)",
    },
  }

  return (
    <div className="flex items-center justify-center space-x-2">
      {[...Array(5)].map((_, index) => (
        <div
          key={index}
          className={`${sizeClasses[size]} rounded-full animate-pulse-dot`}
          style={{
            backgroundColor: colorClasses[color].base,
            animationDelay: `${index * 0.2 - 0.3}s`,
            animationDuration: "1.5s",
            animationIterationCount: "infinite",
            animationTimingFunction: "ease-in-out",
          }}
        />
      ))}

      <style jsx>{`
        @keyframes pulse-dot {
          0% {
            transform: scale(0.8);
            background-color: ${colorClasses[color].base};
            box-shadow: 0 0 0 0 ${colorClasses[color].shadow};
          }
          50% {
            transform: scale(1.2);
            background-color: ${colorClasses[color].active};
            box-shadow: 0 0 0 10px transparent;
          }
          100% {
            transform: scale(0.8);
            background-color: ${colorClasses[color].base};
            box-shadow: 0 0 0 0 ${colorClasses[color].shadow};
          }
        }
        
        .animate-pulse-dot {
          animation: pulse-dot 1.5s infinite ease-in-out;
        }
      `}</style>
    </div>
  )
}
