"use client"

import { memo } from "react"
import { motion } from "framer-motion"
import { LoadingDots } from "./loading-dots"
import Image from "next/image"

interface FullScreenLoadingProps {
  message?: string
  showLogo?: boolean
}

function FullScreenLoadingComponent({ message = "Cargando...", showLogo = true }: FullScreenLoadingProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center z-50"
    >
      <div className="text-center">
        {showLogo && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <div className="relative">
              {/* Fondo suave para el logo */}
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm rounded-2xl transform scale-110 shadow-lg"></div>
              <div className="relative p-6">
                <Image
                  src="/logo-orcoma.png"
                  alt="ORCOMA S.A.S Logo"
                  width={250}
                  height={70}
                  className="mx-auto filter drop-shadow-sm"
                  priority
                />
              </div>
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-4"
        >
          <LoadingDots size="lg" color="orange" />
          <p className="text-gray-600 text-lg font-medium">{message}</p>
        </motion.div>
      </div>
    </motion.div>
  )
}

// Memoizamos el componente para evitar re-renders innecesarios
export const FullScreenLoading = memo(FullScreenLoadingComponent)

export default FullScreenLoading
