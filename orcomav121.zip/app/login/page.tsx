"use client"

import React from "react"
import { useState, useEffect, useCallback, useMemo } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/auth-context"
import { Mail, Lock, Eye, EyeOff, AlertCircle } from "lucide-react"
import Image from "next/image"
import { LoadingDots } from "@/components/loading-dots"

// Componente memoizado para el formulario de login
const LoginForm = React.memo(
  ({
    formData,
    handleInputChange,
    handleLogin,
    showPassword,
    setShowPassword,
    isLoading,
    error,
  }: {
    formData: any
    handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void
    handleLogin: (e: React.FormEvent) => void
    showPassword: boolean
    setShowPassword: (show: boolean) => void
    isLoading: boolean
    error: string
  }) => (
    <motion.form
      key="login"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.3 }}
      onSubmit={handleLogin}
      className="space-y-6"
    >
      {/* Email/Username */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Email o Usuario</label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <motion.input
            whileFocus={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
            type="text"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="admin@test.com o admin"
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm"
            required
            disabled={isLoading}
          />
        </div>
      </div>

      {/* Password */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Contraseña</label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
          <motion.input
            whileFocus={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
            type={showPassword ? "text" : "password"}
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            placeholder="••••••••"
            className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all duration-200 bg-white/50 backdrop-blur-sm"
            required
            disabled={isLoading}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors duration-200"
            disabled={isLoading}
          >
            {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Remember me */}
      <div className="flex items-center justify-between">
        <label className="flex items-center">
          <input
            type="checkbox"
            name="rememberMe"
            checked={formData.rememberMe}
            onChange={handleInputChange}
            className="h-4 w-4 text-orange-500 focus:ring-orange-500 border-gray-300 rounded"
            disabled={isLoading}
          />
          <span className="ml-2 text-sm text-gray-600">Recordarme</span>
        </label>
      </div>

      {/* Error message */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center space-x-2 text-red-600 text-sm bg-red-50 p-3 rounded-lg border border-red-200"
        >
          <AlertCircle className="h-4 w-4" />
          <span>{error}</span>
        </motion.div>
      )}

      {/* Submit button */}
      <motion.button
        whileHover={!isLoading ? { scale: 1.02 } : {}}
        whileTap={!isLoading ? { scale: 0.98 } : {}}
        type="submit"
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
      >
        {isLoading ? (
          <div className="flex items-center justify-center space-x-3">
            <LoadingDots size="sm" color="orange" />
            <span>Iniciando sesión...</span>
          </div>
        ) : (
          "Iniciar Sesión"
        )}
      </motion.button>
    </motion.form>
  ),
)

LoginForm.displayName = "LoginForm"

export default function LoginPage() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  })
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")

  const { login, user, isLoading } = useAuth()
  const router = useRouter()

  // Redirigir si ya está autenticado
  useEffect(() => {
    if (user) {
      router.push("/admin")
    }
  }, [user, router])

  // Handler para cambios en inputs
  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
    setError("")
  }, [])

  // Handler para login
  const handleLogin = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault()
      setError("")

      if (!formData.email || !formData.password) {
        setError("Por favor, completa todos los campos")
        return
      }

      try {
        const success = await login(formData.email, formData.password)
        if (success) {
          // El router.push se maneja en el useEffect cuando user cambia
          console.log("Login exitoso, redirigiendo...")
        } else {
          setError("Credenciales incorrectas. Prueba: admin@test.com / admin123")
        }
      } catch (error) {
        console.error("Error en login:", error)
        setError("Error al iniciar sesión. Intenta nuevamente.")
      }
    },
    [formData.email, formData.password, login],
  )

  // Memoizar el componente del formulario
  const loginFormComponent = useMemo(
    () => (
      <LoginForm
        formData={formData}
        handleInputChange={handleInputChange}
        handleLogin={handleLogin}
        showPassword={showPassword}
        setShowPassword={setShowPassword}
        isLoading={isLoading}
        error={error}
      />
    ),
    [formData, handleInputChange, handleLogin, showPassword, isLoading, error],
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        {/* Logo y título */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-center mb-8"
        >
          <div className="mb-6 relative">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="absolute inset-0 bg-white/60 backdrop-blur-sm rounded-2xl transform scale-110 shadow-xl"
            ></motion.div>

            <motion.div
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="relative p-8"
            >
              <Image
                src="/logo-orcoma-new.webp"
                alt="Orlando Contreras Mantilla - Ingenieros Civiles S.A.S."
                width={400}
                height={120}
                className="mx-auto filter drop-shadow-lg transform hover:scale-105 transition-transform duration-300"
                priority
                style={{
                  filter: "drop-shadow(0 8px 16px rgba(0, 0, 0, 0.15))",
                }}
              />
            </motion.div>
          </div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="text-gray-600 text-sm font-medium"
          >
            SOLUCIONES CON CALIDAD, SERIEDAD Y CUMPLIMENTO
          </motion.p>
        </motion.div>

        {/* Formulario */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-white rounded-xl shadow-xl overflow-hidden backdrop-blur-sm border border-white/20"
        >
          <div className="p-8">
            <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Iniciar Sesión</h2>
            {loginFormComponent}
          </div>
        </motion.div>

        {/* Información de prueba */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.8 }}
          className="mt-6 text-center text-sm text-gray-500 bg-white/40 backdrop-blur-sm rounded-lg p-4 border border-white/20"
        >
          <p className="font-medium mb-2">Usuarios de prueba:</p>
          <div className="space-y-1">
            <p className="font-mono bg-orange-50 px-3 py-2 rounded text-orange-700">
              <span className="font-bold">admin@test.com</span> / <span className="font-bold">admin123</span> (Admin)
            </p>
            <p className="font-mono bg-blue-50 px-3 py-2 rounded text-blue-700">
              <span className="font-bold">user@orcoma.com</span> / <span className="font-bold">user123</span> (Usuario)
            </p>
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}
