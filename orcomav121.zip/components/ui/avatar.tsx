"use client"

import * as React from "react"
import { LogOut } from "lucide-react"
import { useRouter } from "next/navigation"
import { cn } from "@/lib/utils"

const Avatar = React.forwardRef<
  HTMLButtonElement,
  React.ComponentPropsWithoutRef<"button"> & {
    onLogout?: () => void
  }
>(({ className, onLogout, ...props }, ref) => {
  const router = useRouter()

  const handleClick = () => {
    if (onLogout) {
      onLogout()
    }
    router.push("/login")
  }

  return (
    <button
      ref={ref}
      onClick={handleClick}
      className={cn(
        "relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors",
        className,
      )}
      title="Cerrar sesión"
      {...props}
    >
      <LogOut className="h-4 w-4" />
    </button>
  )
})
Avatar.displayName = "Avatar"

// Keep these for compatibility but make them return the logout button
const AvatarImage = React.forwardRef<HTMLButtonElement, React.ComponentPropsWithoutRef<"button">>(
  ({ className, ...props }, ref) => <Avatar ref={ref} className={className} {...props} />,
)
AvatarImage.displayName = "AvatarImage"

const AvatarFallback = React.forwardRef<HTMLButtonElement, React.ComponentPropsWithoutRef<"button">>(
  ({ className, ...props }, ref) => <Avatar ref={ref} className={className} {...props} />,
)
AvatarFallback.displayName = "AvatarFallback"

export { Avatar, AvatarImage, AvatarFallback }
