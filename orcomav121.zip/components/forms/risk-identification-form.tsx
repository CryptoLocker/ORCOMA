"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { FormWrapper } from "./form-wrapper"
import { FormField } from "./form-field"
import { riskIdentificationFormAction } from "@/lib/actions"
import type { FormConfig } from "@/lib/types"
import { showToast } from "@/lib/toast"

const formConfig: FormConfig = {
  id: "risk-identification",
  title: "GESTIÓN DE CALIDAD Y SST",
  description: "Formulario: Identificación de Riesgos - PROYECTOS",
  code: "GCSST-REG-062",
  version: "1",
  date: "1/03/2024",
}

const initialState = {
  defaultValues: {
    sugerencias: "",
    riesgos: {},
  },
  success: false,
  errors: null,
}

const riskCategories = [
  {
    title: "RIESGOS FÍSICOS",
    subcategories: [
      {
        title: "ENERGÍA MECÁNICA",
        risks: [
          { id: "ruido", label: "Ruido" },
          { id: "vibracion", label: "Vibración" },
        ],
      },
      {
        title: "ENERGÍA TÉRMICA",
        risks: [
          { id: "temp_frio", label: "Temperaturas extremas por Frío" },
          { id: "temp_calor", label: "Temperaturas Extremas por Calor" },
        ],
      },
      {
        title: "ENERGÍA ELECTROMECÁNICA",
        risks: [
          { id: "rad_ionizantes", label: "Radiaciones Ionizantes" },
          { id: "rad_no_ionizantes", label: "Radiaciones no Ionizantes" },
        ],
      },
    ],
  },
  {
    title: "RIESGOS QUÍMICOS",
    risks: [
      { id: "vapores", label: "Vapores" },
      { id: "fibras", label: "Fibras" },
      { id: "polvos_humos", label: "Polvos y Humos" },
      { id: "nieblas", label: "Nieblas" },
    ],
  },
  {
    title: "RIESGOS BIOLÓGICOS",
    subcategories: [
      {
        title: "MICROORGANISMOS",
        risks: [
          { id: "virus", label: "Virus" },
          { id: "bacterias", label: "Bacterias" },
          { id: "hongos", label: "Hongos" },
        ],
      },
    ],
  },
  {
    title: "RIESGOS BIOMECÁNICOS",
    subcategories: [
      {
        title: "CARGA FÍSICA",
        risks: [
          { id: "posturas", label: "Posturas inadecuadas" },
          { id: "movimientos", label: "Movimientos repetitivos" },
          { id: "cargas", label: "Manipulación de cargas" },
        ],
      },
    ],
  },
  {
    title: "RIESGOS DE SEGURIDAD",
    risks: [
      { id: "mecanico", label: "Mecánicos" },
      { id: "electrico", label: "Eléctrico" },
      { id: "locativo", label: "Locativos" },
      { id: "tecnologico", label: "Físico-Químico" },
    ],
  },
  {
    title: "RIESGOS FENÓMENOS NATURALES",
    risks: [
      { id: "sismo", label: "Terremotos" },
      { id: "inundacion", label: "Inundaciones" },
      { id: "deslizamiento", label: "Avalanchas" },
    ],
  },
  {
    title: "RIESGOS PÚBLICOS",
    risks: [
      { id: "hurto", label: "Hurto" },
      { id: "manifestaciones", label: "Manifestaciones" },
      { id: "terrorismo", label: "Terrorismo" },
    ],
  },
  {
    title: "RIESGO PSICOSOCIAL",
    risks: [
      {
        id: "estres",
        label: "Se maneja gran cantidad de información, es compleja y/o debe emplearse de manera simultánea",
      },
      {
        id: "responsabilidad",
        label: "Se tiene responsabilidad por manejo de dinero, bienes, salud o seguridad de otras personas",
      },
      { id: "jornadas", label: "Las jornadas de trabajo son extensas, en horario nocturno y/o sin descanso" },
      { id: "trato", label: "Se expone a trato negativo del público y/o de compañeros de trabajo" },
      { id: "comunicacion", label: "La comunicación con otras personas es escasa y/o conflictiva" },
      {
        id: "esfuerzo",
        label: "El trabajo y las condiciones en que se realiza implica un gran esfuerzo físico y fatiga",
      },
    ],
  },
]

export function RiskIdentificationForm() {
  const [state, formAction, pending] = React.useActionState(riskIdentificationFormAction, initialState)

  React.useEffect(() => {
    if (state.success) {
      showToast.success("Formulario enviado correctamente", "La identificación de riesgos ha sido registrada")
    }
  }, [state.success])

  const renderRiskSection = (category: (typeof riskCategories)[0]) => (
    <div key={category.title} className="space-y-4">
      <h4 className="text-lg font-bold text-orange-500">{category.title}</h4>
      {category.subcategories ? (
        category.subcategories.map((subcategory) => (
          <div key={subcategory.title}>
            <h5 className="font-bold text-blue-600">{subcategory.title}</h5>
            <div className="grid grid-cols-2 gap-2">
              {subcategory.risks.map((risk) => (
                <div key={risk.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={risk.id}
                    name={`riesgos.${category.title.toLowerCase()}.${risk.id}`}
                    disabled={pending}
                  />
                  <Label htmlFor={risk.id}>{risk.label}</Label>
                </div>
              ))}
            </div>
          </div>
        ))
      ) : (
        <div className={`grid gap-2 ${category.title === "RIESGO PSICOSOCIAL" ? "grid-cols-1" : "grid-cols-2"}`}>
          {category.risks?.map((risk) => (
            <div key={risk.id} className="flex items-center space-x-2">
              <Checkbox id={risk.id} name={`riesgos.${category.title.toLowerCase()}.${risk.id}`} disabled={pending} />
              <Label htmlFor={risk.id}>{risk.label}</Label>
            </div>
          ))}
        </div>
      )}
    </div>
  )

  return (
    <FormWrapper config={formConfig}>
      <div className="bg-gray-100 p-4 rounded-md mb-6">
        <p>
          <strong>OBJETIVO:</strong> Identificar los RIESGOS relacionados con las ocupaciones o actividades rutinarias y
          no rutinarias que desempeñan todos los cargos o niveles de la organización.
        </p>
        <p>
          <strong>ALCANCE:</strong> Aplica a todos los niveles y cargos de la empresa.
        </p>
        <p>
          <strong>APLICACIÓN:</strong> Al iniciar cada proyecto
        </p>
      </div>

      <form action={formAction} className="space-y-6">
        <h3 className="text-xl font-bold mt-6">IDENTIFICACIÓN DE PELIGROS Y RIESGOS</h3>
        <p>
          Marque únicamente los RIESGOS a los que se expone en su ocupación o mientras realiza sus labores rutinarias y
          no rutinarias en este proyecto.
        </p>

        {riskCategories.map(renderRiskSection)}

        <FormField
          id="sugerencias"
          name="sugerencias"
          label="QUE HACER PARA MINIMIZAR LOS RIESGOS:"
          defaultValue={state.defaultValues.sugerencias}
          disabled={pending}
          error={state.errors?.sugerencias}
          multiline
          rows={4}
        />

        <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600" disabled={pending}>
          {pending ? "Enviando..." : "FIRMA DE TRABAJADOR"}
        </Button>
      </form>
    </FormWrapper>
  )
}
