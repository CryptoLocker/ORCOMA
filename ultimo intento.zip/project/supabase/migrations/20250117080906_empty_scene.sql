/*
  # Esquema inicial para la plataforma de capacitación

  1. Nuevas Tablas
    - `videos`
      - `id` (uuid, clave primaria)
      - `title` (texto, título del video)
      - `description` (texto, descripción del video)
      - `url` (texto, URL del video)
      - `views` (entero, número de visualizaciones)
      - `completion_rate` (decimal, tasa de finalización)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `user_id` (uuid, referencia al usuario que subió el video)

    - `messages`
      - `id` (uuid, clave primaria)
      - `sender_id` (uuid, referencia al usuario que envía)
      - `receiver_id` (uuid, referencia al usuario que recibe)
      - `question` (texto, pregunta enviada)
      - `answer` (texto, respuesta proporcionada)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Seguridad
    - RLS habilitado en todas las tablas
    - Políticas para lectura y escritura basadas en roles de usuario
*/

-- Habilitar la extensión uuid-ossp si no está habilitada
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabla de videos
CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  url text,
  views integer DEFAULT 0,
  completion_rate decimal DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

-- Tabla de mensajes
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id uuid REFERENCES auth.users(id),
  receiver_id uuid REFERENCES auth.users(id),
  question text NOT NULL,
  answer text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Políticas para videos
CREATE POLICY "Videos visibles para todos los usuarios autenticados"
  ON videos FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Solo administradores pueden crear videos"
  ON videos FOR INSERT
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Solo administradores pueden actualizar videos"
  ON videos FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Solo administradores pueden eliminar videos"
  ON videos FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin');

-- Políticas para mensajes
CREATE POLICY "Usuarios pueden ver sus propios mensajes"
  ON messages FOR SELECT
  TO authenticated
  USING (
    auth.uid() = sender_id OR 
    auth.uid() = receiver_id
  );

CREATE POLICY "Usuarios pueden crear mensajes"
  ON messages FOR INSERT
  TO authenticated
  USING (auth.uid() = sender_id);

-- Función para actualizar el timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para actualizar updated_at
CREATE TRIGGER update_videos_updated_at
  BEFORE UPDATE ON videos
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_messages_updated_at
  BEFORE UPDATE ON messages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();